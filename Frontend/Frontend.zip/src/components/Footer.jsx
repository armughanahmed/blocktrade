import React from 'react';
import './Footer.css'

const Footer = () => {
    return (
          <div className="footer-copyright text-center py-3">© 2021 Copyright BlockTrade
              </div>
    )

}

export default Footer;