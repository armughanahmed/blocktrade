import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

class ConsignmentDetails extends PureComponent {
    static propTypes = {}

    constructor(props) {
        super(props)

        this.state = {
            
        }
    }

    render() {
        return (
            
        )
    }
}

export default ConsignmentDetails