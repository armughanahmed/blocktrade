import React from 'react'

function Modal() {
    return (
       <p>Hello</p>
    )
}

export default Modal
