import React, { PureComponent } from 'react'
import NavbarFI from '../../components/NavbarFI';
import Footer from '../../components/Footer';
import MUIDataTable from "mui-datatables";
import './LCPrevious.css'
import ViewDocumentsCard from '../../components/cargoOwner/ViewDocumentsCard'
import ViewDetailsCards from '../../components/cargoOwner/ViewDetailsCards'

class LCPrevious extends PureComponent {
   

    render() {
        return(
            
            <NavbarFI/>
        )
    }
}

export default LCPrevious


